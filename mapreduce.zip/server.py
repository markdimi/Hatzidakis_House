import socket
import sys
import threading
import time
import pickle

class ThreadedServer(object):
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.host, self.port))

    def listen(self):
        listening = True
        self.sock.listen(5)
        print("\nPlease wait for all the clients to connect")
        time.sleep(30)
        print("OK\n")
        time.sleep(1)
        print("PHAZE ONE: Init, Map & Shuffle")
        print("==============================")
        while listening:
            print()
            client, address = self.sock.accept() # socketing
            client.settimeout(120)
            threading.Thread(target = self.run_init,args = (client,address)).start()
            time.sleep(2)
            threading.Thread(target = self.run_map,args = (client,address)).start()
            time.sleep(2)
            threading.Thread(target = self.run_shuffle,args = (client,address)).start()
            time.sleep(2)

            if self.z == int(self.rooms / 2): # workers and reducers
                print("\nPHAZE TWO: Reduce & Reduce")
                print("===========================\n")
                n = int(len(self.clients)/self.z)
                # Divide the list into how many reducers we have
                self.clients_divided = [self.clients[i:i+n] for i in range(0, len(self.clients), n)]
                # if the division has a remainder
                if len(self.clients_divided) > self.z:
                    self.clients_divided[-2].extend(self.clients_divided[-1])
                    self.clients_divided.pop(-1)

                print("The data gets divided into:", self.z, "groups\n")

                while listening:
                    clientt, addresss = self.sock.accept() # socketing
                    clientt.settimeout(80)
                    threading.Thread(target = self.run_reduce,args = (clientt,addresss,self.clients_divided[self.t])).start()
                    time.sleep(3)
                    self.t += 1
                    if self.t == self.rooms - self.z - 1: # reducers and last reducer
                        for i in self.results:
                            self.reduced_results.append(i)
                        print("\nLAST REDUCTION")
                        print("==============\n")
                        clienttt, addressss = self.sock.accept() # socketing
                        clienttt.settimeout(60)
                        threading.Thread(target = self.run_reduce,args = (clienttt,addressss,self.reduced_results)).start()
                        time.sleep(3)
                        print("\n=========RESULTS!=========\n")
                        time.sleep(3)
                        print(self.results[-2], self.results[-1])
                        print("\n==========================\n")
                        listening = False



#####################################################

    def run_init(self, client, address):
        self.x += 1
        command = "Run_Init"
        client.send(command.encode())
        response = client.recv(self.size).decode()
        print("Worker", str(self.x),":", response)

    def run_map(self, client, address):
        self.y += 1
        command = "Run_Map"
        client.send(command.encode())
        response = client.recv(self.size).decode()
        print("Worker", str(self.y),":", response)

    def run_shuffle(self, client, address):
        self.z += 1
        command = "Run_Shuffle"
        client.send(command.encode())
        response = client.recv(self.size)
        lists = pickle.loads(response)
        self.clients.extend(lists)
        ok_msg = "Shuffle_OK"
        print("Worker", str(self.z),":", ok_msg)
        client.close()

    def run_reduce(self, client, address, input_list):
        self.s += 1
        command = "Run_Reduce"
        client.send(command.encode())
        response = client.recv(self.size).decode()
        print("Reducer", str(self.s),":", response)

        client.send(pickle.dumps(input_list))
        response = client.recv(self.size)
        listss = pickle.loads(response)
        self.results.extend(listss)
        ok_msg = "Reduce_OK"
        print("Reducer", str(self.s),":", ok_msg,"\n")
        client.close()

    # def run_reduce(self, client, address, input_list):
    #     self.s += 1
    #     client.send(pickle.dumps(input_list))
    #     response = client.recv(self.size)
    #     listss = pickle.loads(response)
    #     self.results[self.t].extend(listss)
    #     ok_msg = "Reduce_OK"
    #     print("Reducer", str(self.s),":", ok_msg)

    ### helpful data structures and variables
    size = 2048
    x = 0
    y = 0
    z = 0
    t = 0
    s = 0
    rooms = 5
    clients = []
    clients_divided = []
    reduced_results = []
    results = []

####### main

if __name__ == "__main__":
    port_num = int(input("\nPort? "))
    ThreadedServer('',port_num).listen()
    #####
    ##### END
    #####
    #####
    ##### END
    #####
    #####
    ##### END
    #####
    time.sleep(2)
    hpy_smr = '''
    HAPPY SUMMER EVERYONE!

           |
         \ _ /
       -= (_) =-
         /   \         _\/_
           |           //o\  _\/_
    _____ _ __ __ ____ _ | __/o\/\ _
  =-=-_-__=_-= _=_=-=_,-'|"'""-|-,_
   =- _=-=- -_=-=_,-"          |
 jgs =- =- -=.--"
    '''
    print(hpy_smr)
