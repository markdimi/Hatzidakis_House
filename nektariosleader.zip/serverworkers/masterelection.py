import select 
import socket 
import sys
import threading

host = 'localhost' # what address is the server listening on 
port = 5000 # what port the server accepts connections on
backlog = 5  # how many connections to accept
maxsize = 4096 # Max receive buffer size, in bytes, per recv() call

#now initialize the server and accept connections at localhost:50000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
server.bind((host,port)) 
server.listen(backlog) 
input = [server,] #a list of all connections we want to check for data 
                  #each time we call select.select()

running = 1 #set running to zero to close the server
i=0

print "Chat server started on port " + str(port)
var = raw_input("Please specify the number of clients in this system:")
noofclients = int(var)
numberofclients = noofclients
clients_lock = threading.Lock()
clients =set()
answers = []
correctanswers = []
wronganswers = []
flag=0
firstthreshold = float(noofclients)
threshold = float(firstthreshold)/2
print(float(threshold))

while running: 
	inputready,outputready,exceptready = select.select(input,[],[]) 

	for s in inputready: #check each socket that select() said has available data

		if s == server: #if select returns our server socket, there is a new 
                    #remote socket trying to connect
			client, address = server.accept() 
			
			input.append(client) #add it to the socket list so we can check it now
			print 'new client added%s'%str(address)
			with clients_lock:
				clients.add(client)

		else: 
      # select has indicated that these sockets have data available to recv
			data = s.recv(maxsize) 
			if data:
				print '%s received from %s'%(data,s.getsockname())

        #Uncomment below to echo the recv'd data back 
        #to the sender... loopback!
				if data == 'ready':
					answers.append(data)
					if len(answers) == noofclients:
						print('System start with clients:'+str(noofclients))
						print("\n 1. check clients")
						print("\n 2. election")
						print("\n 3. terminate all clients")
						print("\n 4. notify leadership")
						ans=raw_input("What would you like to do? ") 
    						if ans=="1": 
      							print("\ncheck started")
							with clients_lock:
								for c in clients:
									data='check'
        								c.sendall(data)
									data=''
									answers=[]
									flag=1
    						elif ans=="2":
      							print("\nelection started")
							with clients_lock:
								for c in clients:
									data='election'
        								c.sendall(data)
									data=''
									answers=[]
									flag=2
    						elif ans=="3":
      							print("\nterminate all clients")
							with clients_lock:
								for c in clients:
									data='terminate'
        								c.sendall(data)
									data=''
									answers=[]
    						elif ans=="4":
      							print("\n notify leadership")
							with clients_lock:
								for c in clients:
									data='notifyleadership' 
    						elif ans !="":
      							print("\n Not Valid Choice Try again") 	
					else:
						pass
				elif data != 'ready':
					if flag == 1:
						answers.append(data)
						if data == 'checkok':
							correctanswers.append(data)
							if len(answers) == noofclients:
								print("mikoscorrect:"+str(len(correctanswers)))
								print("Threshold:"+str(threshold))
								if len(correctanswers) > threshold:
									with clients_lock:
										for c in clients:
											data = 'continue'
											c.sendall(data)
											data=''
											answers=[]
											correctanswers=[]
											flag = 1
								else:
									print('System either corrupt or needs new leader')
									print("\nStarting election")
									with clients_lock:
										for c in clients:
											data='election'
        										c.sendall(data)
											flag = 2
											data=''
											answers=[]
						elif data != 'checkok' and len(answers) == noofclients:
							print("mikoscorrect:"+str(len(correctanswers)))
							print("Threshold:"+str(threshold))
							if len(correctanswers) > threshold:
								with clients_lock:
									for c in clients:
										data = 'continue'
										c.sendall(data)
										data=''
										answers = []
										correctanswers=[]
										flag=1
							else:
								print("mikoscorrect:"+str(len(correctanswers)))
								print("Threshold:"+str(threshold))
								print('System corrupt or needs new leader')
								print("\nstarting election")
								with clients_lock:
									for c in clients:
										data='election'
        									c.sendall(data)
										flag=2
										data=''
										answers=[]
						else:
							pass
					elif flag == 2:
						pass
							#print('System corrupt')
							#print("\nterminate all clients")
							#with clients_lock:
							#	for c in clients:
							#		data='terminate'
        						#		c.sendall(data)
							#		data=''
							#		answers=[]
					#if data == 'checkok':
						#print('check ok apo client')
						#answers.append(data)
						#print(answers)
						#if len(answers) == noofclients:
						#	with clients_lock:
						#		for c in clients:
								#	data='continue'
        							#	c.sendall(data)
								#	data=''
								#	answers=[]
					#elif data == 'electionstarted':
					#	answers.append(data)
					#	if len(answers) == noofclients:
					#		with clients_lock:
					#			for c in clients:
					#				data='proceedwithelection'
        				#				c.sendall(data)
					#				data=''
					#				answers=[]
					#	else:
					#		pass
			else: #if recv() returned NULL, that usually means the sender wants
            #to close the socket. 
				s.close() 
				input.remove(s) 

#if running is ever set to zero, we will call this
server.close()
