import socket
import sys

HOST, PORT = "localhost", 5000
#data = "nektarios".join(sys.argv[1:])
data = "ready"
# Create a socket (SO.CK_STREAM means a TCP socket)
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    	# Connect to server and send data
    	sock.connect((HOST, PORT))
    	sock.send(data)

    # Receive data from the server and shut down
	while 1:
   		received = sock.recv(4096)
		MasterMessage = received.decode()
		#print (received)
		if received == 'check':
			print("mpike sto check")
		#deyteri fora epikoinonia me master
			sock.send("checkok")	
		elif MasterMessage == 'election':
			print("mpike gia election")
			sock.send("electionstarted")
		elif MasterMessage == 'terminate':
			print("mpike gia terminate")
			break
		elif MasterMessage == 'continue':
			print("mpike gia continue")
		elif MasterMessage == 'proceedwithelection':
			print("mpike gia diadikasia election")
		else:
			print(MasterMessage)
			#sock.send("ready")
			print("mpike edo")
			
			print "Sent:     {}".format(data)
			print "Received: {}".format(received)
			break
			
			
finally:
    	#sock.close()
	pass

	
