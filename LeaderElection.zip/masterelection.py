import select 
import socket 
import sys
import threading
import time
import pickle
import random

class ThreadedServer(object):
        threshold = 0
        flag = 0
        data=''
        answers=[]
        clients_lock = threading.Lock()
        address_lock = threading.Lock()
        clients = set()
        addressbook = []
        clientLeaderAddress=''
        theLeader=0
        
        def __init__(self, host, port):
                self.host = host
                self.port = port
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                self.sock.bind((self.host, self.port))
                #self.sock.connect((self.host, self.port))
     
        #Function in which the master checks the answers of the clients
        #after the notification of the new leader.
        def notifyLeader(self, answers, clients):
                indexval = 0
                correctAnswers = []
                wrongAnswers = []
                print(answers)
                for i in range(len(answers)):
                        if(answers[indexval] == 'leaderNotificationOk'):
                                correctAnswers.append(answers[indexval])
                        else:
                                wrongAnswers.append(answers[indexval])
                        indexval+=1
                if(len(correctAnswers)>self.threshold):
                        with self.clients_lock:
                                for c in self.clients:
                                        self.data='continue'
                                        c.sendall(self.data.encode())
                                        self.data=''
                                        self.answers=[]
                                        self.flag=0
                else:
                        with self.clients_lock:
                                for c in self.clients:
                                        self.data='corrupt'
                                        c.sendall(self.data.encode())
                                        self.sock.close()
        #Function in which the master checks the answers of the clients after
        #the "alive" check.
        def checkClients(self, answers, clients):
                indexval = 0
                correctAnswers = []
                wrongAnswers = []
                print(answers)
                for i in range(len(answers)):
                        if(answers[indexval] == 'checkOK'):
                                correctAnswers.append(answers[indexval])
                        else:
                                wrongAnswers.append(answers[indexval])
                        indexval+=1
                if(len(correctAnswers)>self.threshold):
                        
                        with self.clients_lock:
                                for c in self.clients:
                                        self.data='continue'
                                        c.sendall(self.data.encode())
                                        self.data=''
                                        self.answers=[]
                                        self.flag=0
                else:
                        with self.clients_lock:
                                for c in self.clients:
                                        self.data='corrupt'
                                        c.sendall(self.data.encode())
                                        self.sock.close()
        #Function to produce an election result to notify later who is the leader.
        def election(self, answers,clients):
                indexval = 0
                correctAnswers = []
                wrongAnswers = []
                print(answers)
                for i in range(len(answers)):
                        if(answers[indexval] == 'electionOK'):
                                correctAnswers.append(answers[indexval])
                        else:
                                wrongAnswers.append(answers[indexval])
                        indexval+=1
                print(correctAnswers)
                print(wrongAnswers)
                print(self.threshold)
                if(len(correctAnswers)>self.threshold):
                        self.theLeader = random.randint(0,len(answers))
                        with self.clients_lock:
                                for c in self.clients:
                                        self.data='continue'
                                        c.sendall(self.data.encode())
                                        self.data=''
                                        self.answers=[]
                                        self.flag=0
                else:
                        with self.clients_lock:
                                for c in self.clients:
                                        self.data='corrupt'
                                        c.sendall(self.data.encode())
                                        self.sock.close() 

        def listen(self):
                host = 'localhost' # what address is the server listening on 
                port = 5000   # what port the server accepts connections on
                backlog = 5  # how many connections to accept
                maxsize = 4096 # Max receive buffer size, in bytes, per recv() call

                #now initialize the server and accept connections at localhost:50000
 
                self.sock.listen(backlog) 
                inputted = [self.sock,] #a list of all connections we want to check for data 
                                  #each time we call select.select()

                running = 1 #set running to zero to close the server
                i=0

                print("Chat server started on port" + str(self.port))
                var = input("Please specify the number of clients in this system:")
                noofclients = int(var)
                numberofclients = noofclients
                thenumber=str(noofclients)
                
                correctanswers = []
                wronganswers = []
                firstthreshold = float(noofclients)
                self.threshold = float(firstthreshold)/2
                print(float(self.threshold))

                while running:
                        inputready,outputready,exceptready = select.select(inputted,[],[]) 

                        for s in inputready: #check each socket that select() said has available data

                                if s == self.sock: #if select returns our server socket, there is a new socket trying to connect
                                        client, address = self.sock.accept()
                                        client.settimeout(15)
                                        
                                        inputted.append(client) #add it to the socket list so we can check it now
                                        print ('new client added%s'%str(address))
                                        #creating a list with all the addressess of the connected peers.
                                        #self.addressbook.append(self.sock.getpeername())
                                        with self.clients_lock:
                                                self.clients.add(client)
                                                
                                else: 
                      # select has indicated that these sockets have data available to recv
                                        #print(self.clients)
                                        received = s.recv(maxsize)
                                        self.data = received.decode()
                                        if s.getpeername() not in self.addressbook:
                                                self.addressbook.append(s.getpeername())
                                        print('%s received from %s'%(self.data,s.getpeername()))
                                        if received:
                                                self.answers.append(self.data)
                                                if len(self.answers) == noofclients:
                                                        if(self.flag==0):
                                                                print('System start with clients:'+str(noofclients))
                                                                print("\n 1. check clients")
                                                                print("\n 2. election")
                                                                print("\n 3. notify leadership")
                                                                print("\n 4. terminate all clients")
                                                                print("\n 5. Exit")
                                                                ans=input("What would you like to do? ")
                                                                if ans=="1":
                                                                        print("\nCheck started")
                                                                        with self.clients_lock:
                                                                                for c in self.clients:
                                                                                        self.data='check'
                                                                                        c.sendall(self.data.encode())
                                                                                        self.data=''
                                                                                        self.answers=[]
                                                                                        self.flag=1
                                                                if ans=="2":
                                                                        print("\nElection started")
                                                                        with self.clients_lock:
                                                                                for c in self.clients:
                                                                                        self.data='election'
                                                                                        c.sendall(self.data.encode())
                                                                                        self.data=''
                                                                                        self.answers=[]
                                                                                        self.flag=2
                                                                if ans=="3":
                                                                        print("\nNotify leadership")
                                                                        with self.clients_lock:
                                                                                for c in self.clients:
                                                                                        self.data='Notify leadership-'+str(self.addressbook[self.theLeader]) #Must append the address of the leader.
                                                                                        c.sendall(self.data.encode())
                                                                                        self.data=''
                                                                                        self.answers=[]
                                                                                        self.flag=3
                                                                if ans=="4":
                                                                        print("\nTerminate all clients")
                                                                        with self.clients_lock:
                                                                                for c in self.clients:
                                                                                        self.data='terminate'
                                                                                        c.sendall(self.data.encode())
                                                                                        self.data=''
                                                                                        self.answers=[]
                                                                                        self.flag=0
                                                                        self.clients = set()
                                                                if ans=="5" :
                                                                        print("\nExiting")
                                                                        with self.clients_lock:
                                                                                for c in self.clients:
                                                                                        self.data='terminate'
                                                                                        c.sendall(self.data.encode())
                                                                                        self.data=''
                                                                                        self.answers=[]
                                                                                        self.flag=0
                                                                        self.clients = set()                                                                        
                                                                        self.sock.close()
                                                                        break              
                                                        elif(self.flag==1):
                                                                threading.Thread(target = self.checkClients,args = (self.answers,self.clients)).start()
                                                                print("\nCheck clients finished!")
                                                        elif(self.flag==2):
                                                                threading.Thread(target = self.election,args = (self.answers,self.clients)).start()
                                                                print("\nElection finished!")
                                                        elif(self.flag==3):
                                                                threading.Thread(target = self.notifyLeader,args = (self.answers,self.clients)).start()
                                                                print("\nNotify leader to clients finished!")
                                        else:
                                                s.close()
                                                inputted.remove(s)
                                         
                self.sock.close()

#here comes the main
if __name__ == '__main__':
        port_num = int(input("\nPort?"))
        ThreadedServer('localhost',port_num).listen()


