import select
import socket
import sys
import threading
import time

HOST, PORT = "localhost", 5000
#HOST1, PORT1 = "localhost", 5016
backlog = 5
maxsize = 4096
data = 'ready'
# Create a socket (SO.CK_STREAM means a TCP socket)
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
electionsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
flag =1
num=0

try:
# Connect to server and send data
        listening=True
        sock.connect((HOST, PORT))
        sock.send(data.encode())
        #print(sock.getpeername())
        print("I am a worker")
        #Receive data from server and shut down
        while listening:
                received, addr = sock.recvfrom(4096)
                MasterMessage = received.decode()
                print(MasterMessage)
                if MasterMessage =='run_init':
                        print("I am ready to init")
                        response_check='ready'
                        sock.send(response_check.encode())
                if MasterMessage == 'check':
                        print("I am in a check mode.")
                        response_check = 'checkOK'
                        sock.send(response_check.encode())
                elif MasterMessage == 'continue':
                        print("I continue my operations.")
                        response_continue = 'ready'
                        sock.send(response_continue.encode())
                elif MasterMessage == 'terminate':
                        print("Getting ready to terminate.")
                        sock.close()
                        break;
                elif MasterMessage == 'corrupt':
                        print("Getting ready to terminate due to corruption.")
                        sock.close()
                        break;
                elif MasterMessage.startswith('Notify leadership-'):
                        print("I acknowledge leader anouncement.")
                        address=str(sock.getsockname())
                        finalAddress = str(MasterMessage.rpartition('-')[2])
                        if address == finalAddress:
                                print("I am leader")
                        else:
                                print("The leader is client:"+finalAddress)
                        response_leaderNotifyOk = 'leaderNotificationOk'
                        sock.send(response_leaderNotifyOk.encode())
                elif MasterMessage == 'election':
                        print("I participate in elections. I want to be leader.")
                        response_election = 'electionOK'
                        sock.send(response_election.encode())

finally:
        sock.close()
        pass
                
