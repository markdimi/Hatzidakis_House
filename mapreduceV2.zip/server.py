#!/usr/bin/env python

import select
import socket
import sys
import threading
import time
import pickle

class Server:
    def __init__(self):
        self.host = ''
        self.port = int(raw_input("port? \n"))
        self.backlog = 5
        self.size = 1024
        self.server = None
        self.threads = []

    def open_socket(self):
        try:
            self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server.bind((self.host,self.port))
            self.server.listen(5)
        except socket.error, (value,message):
            if self.server:
                self.server.close()
            print "Could not open socket: " + message
            sys.exit(1)

    def run(self):
        self.open_socket()
        input = [self.server,sys.stdin]
        running = 1
        while running:
            inputready,outputready,exceptready = select.select(input,[],[])

            for s in inputready:

                if s == self.server:
                    # handle the server socket

                    # print("Waiting...")
                    # time.sleep(30)
                    # print("Let's Go!")

                    c = Client(self.server.accept())
                    c.start()
                    self.threads.append(c)

                elif s == sys.stdin:
                    # handle standard input
                    junk = sys.stdin.readline()
                    running = 0

        # close all threads
        print("exiting")
        self.server.close()
        for c in self.threads:
            c.join()

class Client(threading.Thread):
    def __init__(self,(client,address)):
        threading.Thread.__init__(self)
        self.client = client
        self.address = address
        self.size = 1024

    def run(self):
        running = 1
        while running:
            self.run_init(self.client, self.address)
            self.run_map(self.client, self.address)
            self.run_shuffle(self.client, self.address)


            time.sleep(30)

            if len(self.clients) > self.x:
                self.x = int(len(self.clients) / self.rooms)

            if len(self.clients) >= self.x:
                self.clients_divided = self.clients[0:self.x]
                self.clients = self.clients[self.x:]
            else:
                self.clients_divided = list(self.clients)
                self.clients = []

            self.run_reduce(self.client, self.address, self.clients_divided)
            # print(self.results)
            # print(len(self.results))

            if len(self.results) == 2 * self.rooms:
                print("\n\nLast Reduce:")
                print(self.results)
                self.run_reduce(self.client, self.address, self.results)
                print("\n\nResult of Map Reduce:")
                print(self.results[-2], self.results[-1] )
                self.results = []
                time.sleep(58)
            else:
                time.sleep(60)


    def run_init(self, client, address):
        command = "Run_Init"
        client.send(command.encode())
        response = client.recv(self.size).decode()
        print("Worker:", response)

    def run_map(self, client, address):
        command = "Run_Map"
        client.send(command.encode())
        response = client.recv(self.size).decode()
        print("Worker:", response)

    def run_shuffle(self, client, address):
        command = "Run_Shuffle"
        client.send(command.encode())
        response = client.recv(self.size)
        lists = pickle.loads(response)
        self.clients.extend(lists)
        ok_msg = "Shuffle_OK"
        print("Worker:", ok_msg)

    def run_reduce(self, client, address, input_list):
        command = "Run_Reduce"
        client.send(command.encode())
        response = client.recv(self.size).decode()
        print("Reducer:", response)

        client.send(pickle.dumps(input_list))
        response = client.recv(self.size)
        listss = pickle.loads(response)
        self.results.extend(listss)
        ok_msg = "Reduce_OK"
        print("Reducer:", ok_msg,"\n")

    size = 1024
    x = 0
    y = 0
    z = 0
    t = 0
    s = 0
    rooms = 3
    clients = []
    clients_divided = []
    reduced_results = []
    results = []

if __name__ == "__main__":
    s = Server()
    s.run()
