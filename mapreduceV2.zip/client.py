import random
import socket
import sys
import pickle

def initialize(host):
    clients = {}
    gender=['man','woman']
    rand_clients_numb = random.randint(10,50) # the people in the room will be a random number
    for i in range(1, rand_clients_numb):
            rand_gender = random.choice(gender)
            clients.update({"EDC[" + host + "]:" + str(i) : rand_gender})
    #checking data
    print("SCANNING THE ROOM")
    print("*****************\n")
    print(clients)
    print("****************************************************")
    print("In more detail, the room is filled with", len(clients), "people\n")
    return clients

def map(map_input):
    map_output = [] # lists will do for this task, dictionaries require unique keys
    for gender in map_input.values():
        map_output.append([gender, 1])

    #just checking
    print("Mapped data:")
    print("************")
    print(map_output)
    return map_output

def reduce(reduce_input):
        man = 0
        woman = 0
        print("You sended this list:")
        print("*********************\n")
        print(reduce_input)
        for i in range(len(reduce_input)):
            if reduce_input[i][0] == "man":
                man += int(reduce_input[i][1])
            else:
                woman += int(reduce_input[i][1])
        reduce_output = [["man", man], ["woman", woman]]
        print("\nAnd it's reduced into:")
        print("**********************")
        print(reduce_output)
        return reduce_output


####### main
######
#####


# create a socket object
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# ip and port specifications
server = "localhost"
#server = input("Server hostname or ip? ")
port = int(input("\nServer port? "))
# connection to hostname on the port.

sock.connect((server,port))

# get local machine name
try:
        host = socket.gethostname()
except sock.gaierror:
        #could not resolve
        print ('Hostname could not be resolved. Exiting...')
        sys.exit()

print("\nWELCOME")
print("=========\n")

## Some variables and data structures for the functions
client_operational = True
size = 4096
map_input = None
mapper_output = None

# #Sending Hello message to server
# #lets use the hostname as the first message :)
# first_master_message = sock.recv(size).decode()
# print(first_master_message)
# sock.send(host.encode())

#### SO IT BEGINS

while client_operational:
    master_message = sock.recv(size).decode()

    #option 1
    if master_message == "Run_Init": # masters option
        map_input = initialize(host) # running the function on the data
        response_init = "Init_OK" # responding
        sock.send(response_init.encode())

    #option 2
    elif master_message == "Run_Map":
        mapper_output = map(map_input)
        response_map = "Map_OK"
        sock.send(response_map.encode())
    #option 3
    elif master_message == "Run_Shuffle":
        sock.send(pickle.dumps(mapper_output))

    #option 4
    elif master_message == "Run_Reduce":
        response = "Go ahead"
        sock.send(response.encode())
        data = sock.recv(size)
        reduce_input = pickle.loads(data)
        reduce_output = reduce(reduce_input)
        sock.send(pickle.dumps(reduce_output))
